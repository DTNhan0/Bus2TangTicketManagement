import React from "react";

const PaymentInfoForm = () => {};
export default React.memo(PaymentInfoForm);
